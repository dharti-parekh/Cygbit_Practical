const chai = require('chai');
const chaiHttp = require('chai-http');
const app = require('../routes/postRoutes');
const Post = require('../models/Posts');
const User = require('../models/Users');
const mongoose = require('mongoose');
const expect = chai.expect;

chai.use(chaiHttp);

describe('Posts API', () => {
    let userToken;
    let postId;
    const userId = mongoose.Types.ObjectId();

    // Mock user data
    const user = new User({
        _id: userId,
        name: 'Dharti Parekh',
        email: 'dharti@test.com',
        password: 'dharti97'
    });

    // Mock post data
    const post = new Post({
        title: 'Test Post',
        content: 'Test Content',
        userId: userId
    });

    before(async () => {
        await User.deleteMany({});
        await Post.deleteMany({});
        await user.save();
        await post.save();
        postId = post._id;

        userToken = 'Bearer mockToken';
    });

    describe('POST /posts', () => {
        it('should create a new post when the user is authenticated', (done) => {
            const newPost = {
                title: 'New Post Title',
                content: 'New Post Content'
            };

            chai.request(app)
                .post('/posts')
                .set('Authorization', userToken)
                .send(newPost)
                .end((err, res) => {
                    expect(res).to.have.status(201);
                    expect(res.body).to.be.an('object');
                    expect(res.body).to.have.property('title').eql(newPost.title);
                    expect(res.body).to.have.property('content').eql(newPost.content);
                    expect(res.body).to.have.property('userId').eql(userId.toString());
                    postId = res.body._id; // Save the post ID for later use
                    done();
                });
        });

        it('should return an error when the user is not authenticated', (done) => {
            const newPost = {
                title: 'New Post Title',
                content: 'New Post Content'
            };

            chai.request(app)
                .post('/posts')
                .send(newPost)
                .end((err, res) => {
                    expect(res).to.have.status(401);
                    expect(res.body).to.have.property('message').eql('Unauthorized');
                    done();
                });
        });
    });

    describe('GET /posts', () => {
        it('should return the first page of posts with the specified limit', (done) => {
            const limit = 10;
            const page = 1;

            chai.request(app)
                .get(`/posts?limit=${limit}&page=${page}`)
                .set('Authorization', userToken)
                .end((err, res) => {
                    expect(res).to.have.status(200);
                    expect(res.body).to.be.an('array');
                    expect(res.body.length).to.eql(limit);
                    expect(res.body[0]).to.have.property('title').eql('Post 0');
                    expect(res.body[limit - 1]).to.have.property('title').eql('Post 9');
                    done();
                });
        });

        it('should return the second page of posts with the specified limit', (done) => {
            const limit = 10;
            const page = 2;

            chai.request(app)
                .get(`/posts?limit=${limit}&page=${page}`)
                .set('Authorization', userToken)
                .end((err, res) => {
                    expect(res).to.have.status(200);
                    expect(res.body).to.be.an('array');
                    expect(res.body.length).to.eql(limit);
                    expect(res.body[0]).to.have.property('title').eql('Post 10');
                    expect(res.body[limit - 1]).to.have.property('title').eql('Post 19');
                    done();
                });
        });

        it('should return an empty array if the page number is too high', (done) => {
            const limit = 10;
            const page = 4;

            chai.request(app)
                .get(`/posts?limit=${limit}&page=${page}`)
                .set('Authorization', userToken)
                .end((err, res) => {
                    expect(res).to.have.status(200);
                    expect(res.body).to.be.an('array');
                    expect(res.body.length).to.eql(0);
                    done();
                });
        });

        it('should return an error if the user is not authenticated', (done) => {
            const limit = 10;
            const page = 1;

            chai.request(app)
                .get(`/posts?limit=${limit}&page=${page}`)
                .end((err, res) => {
                    expect(res).to.have.status(401);
                    expect(res.body).to.have.property('message').eql('Unauthorized');
                    done();
                });
        });
    });

    describe('GET /posts/:id', () => {
        it('should return the post details if the user is authorized', (done) => {
            chai.request(app)
                .get(`/posts/${postId}`)
                .set('Authorization', userToken)
                .end((err, res) => {
                    expect(res).to.have.status(200);
                    expect(res.body).to.be.an('object');
                    expect(res.body).to.have.property('_id').eql(postId.toString());
                    expect(res.body).to.have.property('title').eql(post.title);
                    expect(res.body).to.have.property('content').eql(post.content);
                    done();
                });
        });

        it('should return an error if the post was not created by the logged-in user', (done) => {
            const anotherUserId = mongoose.Types.ObjectId();
            const anotherPost = new Post({
                title: 'Another Post',
                content: 'Another Content',
                userId: anotherUserId
            });

            anotherPost.save().then(() => {
                chai.request(app)
                    .get(`/posts/${anotherPost._id}`)
                    .set('Authorization', userToken)
                    .end((err, res) => {
                        expect(res).to.have.status(403);
                        expect(res.body).to.have.property('message').eql('You are not authorized to view this post');
                        done();
                    });
            });
        });
    });

    describe('PATCH /posts/:id', () => {
        it('should update the post if the user is authorized', (done) => {
            const updatedPost = {
                title: 'Updated Post Title',
                content: 'Updated Content'
            };

            chai.request(app)
                .patch(`/posts/${postId}`)
                .set('Authorization', userToken)
                .send(updatedPost)
                .end((err, res) => {
                    expect(res).to.have.status(200);
                    expect(res.body).to.be.an('object');
                    expect(res.body).to.have.property('message').eql('Post updated successfully');
                    expect(res.body.post).to.have.property('title').eql(updatedPost.title);
                    expect(res.body.post).to.have.property('content').eql(updatedPost.content);
                    done();
                });
        });

        it('should return an error if the post was not created by the logged-in user', (done) => {
            const anotherUserId = mongoose.Types.ObjectId();
            const anotherPost = new Post({
                title: 'Another Post',
                content: 'Another Content',
                userId: anotherUserId
            });

            anotherPost.save().then(() => {
                const updatedPost = {
                    title: 'Updated Post Title',
                    content: 'Updated Content'
                };

                chai.request(app)
                    .patch(`/posts/${anotherPost._id}`)
                    .set('Authorization', userToken)
                    .send(updatedPost)
                    .end((err, res) => {
                        expect(res).to.have.status(403);
                        expect(res.body).to.have.property('message').eql('You are not authorized to update this post');
                        done();
                    });
            });
        });
    });

    describe('DELETE /posts/:id', () => {
        it('should delete the post if the user is authorized', (done) => {
            chai.request(app)
                .delete(`/posts/${postId}`)
                .set('Authorization', userToken)
                .end((err, res) => {
                    expect(res).to.have.status(200);
                    expect(res.body).to.have.property('message').eql('Post deleted successfully');
                    done();
                });
        });

        it('should return an error if the post was not created by the logged-in user', (done) => {
            const anotherUserId = mongoose.Types.ObjectId();
            const anotherPost = new Post({
                title: 'Another Post',
                content: 'Another Content',
                userId: anotherUserId
            });

            anotherPost.save().then(() => {
                chai.request(app)
                    .delete(`/posts/${anotherPost._id}`)
                    .set('Authorization', userToken)
                    .end((err, res) => {
                        expect(res).to.have.status(403);
                        expect(res.body).to.have.property('message').eql('You are not authorized to delete this post');
                        done();
                    });
            });
        });
    });

    after(async () => {
        await User.deleteMany({});
        await Post.deleteMany({});
    });
});
