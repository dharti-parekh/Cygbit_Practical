const chai = require('chai');
const chaiHttp = require('chai-http');
const app = require('../routes/authRoutes');
const User = require('../models/User');
const expect = chai.expect;

chai.use(chaiHttp);

describe('Authentication API', () => {
    before(async () => {
        await User.deleteMany({});
    });

    describe('POST /auth/register', () => {
        it('should register a new user', (done) => {
            chai.request(app)
                .post('/auth/register')
                .send({
                    name: 'Dharti parekh',
                    email: 'dharti@test.com',
                    password: 'dharti97'
                })
                .end((err, res) => {
                    expect(res).to.have.status(201);
                    expect(res.body).to.be.an('object');
                    expect(res.body).to.have.property('name').eql('Dharti parekh');
                    expect(res.body).to.have.property('email').eql('dharti@test.com');
                    expect(res.body).to.have.property('role').eql('admin');
                    done();
                });
        });

        it('should return an error if email already exists', (done) => {
            // Register the same user again
            chai.request(app)
                .post('/auth/register')
                .send({
                    name: 'Dharti parekh',
                    email: 'dharti@test.com',
                    password: 'dharti97'
                })
                .end((err, res) => {
                    expect(res).to.have.status(400);
                    expect(res.body).to.have.property('message').eql('Email already exists');
                    done();
                });
        });
    });

    describe('POST /auth/login', () => {
        it('should login an existing user', (done) => {
            chai.request(app)
                .post('/auth/login')
                .send({
                    email: 'dharti@test.com',
                    password: 'dharti97'
                })
                .end((err, res) => {
                    expect(res).to.have.status(200);
                    expect(res.body).to.be.an('object');
                    expect(res.body).to.have.property('token');
                    expect(res.body).to.have.property('userId');
                    done();
                });
        });

        it('should return an error if credentials are invalid', (done) => {
            chai.request(app)
                .post('/auth/login')
                .send({
                    email: 'invalid.email@example.com',
                    password: 'wrongpassword'
                })
                .end((err, res) => {
                    expect(res).to.have.status(401);
                    expect(res.body).to.have.property('message').eql('Invalid credentials');
                    done();
                });
        });
    });

    after(async () => {
        // Clean up after tests
        await User.deleteMany({});
    });
});
