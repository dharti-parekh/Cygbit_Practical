const chai = require('chai');
const chaiHttp = require('chai-http');
const app = require('../routes/userRoutes');
const User = require('../models/User');
const mongoose = require('mongoose');
const expect = chai.expect;

chai.use(chaiHttp);

describe('Users API', () => {
    let userToken;
    let userId = mongoose.Types.ObjectId();

    // Mock user data
    const users = [
        {
            _id: userId,
            name: 'Dharti parekh',
            email: 'dharti@test.com',
            password: 'dharti97',
            role: 'admin'
        },
        {
            _id: mongoose.Types.ObjectId(),
            name: 'Smith shah',
            email: 'smith@example.com',
            password: 'password456',
            role: 'user'
        }
    ];

    before(async () => {
        await User.deleteMany({});
        await User.insertMany(users);

        userToken = 'Bearer mockToken';
    });

    describe('GET /users', () => {
        it('should return all users', (done) => {
            chai.request(app)
                .get('/users')
                .set('Authorization', userToken)
                .end((err, res) => {
                    expect(res).to.have.status(200);
                    expect(res.body).to.be.an('array');
                    expect(res.body.length).to.eql(users.length);
                    done();
                });
        });

        it('should return a specific user by ID', (done) => {
            chai.request(app)
                .get(`/users/${userId}`)
                .set('Authorization', userToken)
                .end((err, res) => {
                    expect(res).to.have.status(200);
                    expect(res.body).to.be.an('object');
                    expect(res.body).to.have.property('_id').eql(userId.toString());
                    expect(res.body).to.have.property('name').eql('Dharti parekh');
                    expect(res.body).to.have.property('email').eql('dharti@test.com');
                    expect(res.body).to.have.property('role').eql('admin');
                    done();
                });
        });

        it('should return 404 if the user ID is not found', (done) => {
            const nonExistentUserId = mongoose.Types.ObjectId();

            chai.request(app)
                .get(`/users/${nonExistentUserId}`)
                .set('Authorization', userToken)
                .end((err, res) => {
                    expect(res).to.have.status(404);
                    expect(res.body).to.have.property('message').eql('User not found');
                    done();
                });
        });

        it('should return an error if the user is not authenticated', (done) => {
            chai.request(app)
                .get('/users')
                .end((err, res) => {
                    expect(res).to.have.status(401);
                    expect(res.body).to.have.property('message').eql('Unauthorized');
                    done();
                });
        });
    });

    describe('User API - Retrieve User by ID', () => {
        let userToken;
        let userId;

        // Mock user data
        const user = {
            _id: mongoose.Types.ObjectId(),
            name: 'Dharti parekh',
            email: 'dharti@test.com',
            password: 'dharti97'
        };

        before(async () => {
            await User.deleteMany({});
            await User.create(user);

            userToken = 'Bearer mockToken';
            userId = user._id;
        });

        it('should return a specific user by ID', (done) => {
            chai.request(app)
                .get(`/users/${id}`)
                .set('Authorization', userToken)
                .end((err, res) => {
                    expect(res).to.have.status(200);
                    expect(res.body).to.be.an('object');
                    expect(res.body).to.have.property('_id').eql(userId.toString());
                    expect(res.body).to.have.property('name').eql('Dharti parekh');
                    expect(res.body).to.have.property('email').eql('dharti@test.com');
                    expect(res.body).to.have.property('role').eql('admin');
                    done();
                });
        });

        it('should return 404 if the user ID is not found', (done) => {
            const nonExistentUserId = mongoose.Types.ObjectId();

            chai.request(app)
                .get(`/users/${nonExistentUserId}`)
                .set('Authorization', userToken)
                .end((err, res) => {
                    expect(res).to.have.status(404);
                    expect(res.body).to.have.property('message').eql('User not found');
                    done();
                });
        });

        it('should return an error if the user is not authenticated', (done) => {
            chai.request(app)
                .get(`/users/${userId}`)
                .end((err, res) => {
                    expect(res).to.have.status(401);
                    expect(res.body).to.have.property('message').eql('Unauthorized');
                    done();
                });
        });


        after(async () => {
            await User.deleteMany({});
        });
    });
});
