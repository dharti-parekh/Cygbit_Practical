const express = require('express');
const router = express.Router();
const User = require('./../models/Users');
const { jwtAuthMiddleware } = require('./../jwt');

// get all users list
router.get('/', jwtAuthMiddleware, async (req, res) => {
    try {
        // Find all users
        const result = await User.find({},);

        // Return the list of users
        res.status(200).json(result);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Retrieve details of a specific user by ID.
router.get('/:id', jwtAuthMiddleware, async (req, res) => {
    try {
        // Retrieve details of a specific user by ID.
        const result = await User.findById({ _id: req.params.id },);

        // Return the result
        res.status(200).json(result);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

module.exports = router;