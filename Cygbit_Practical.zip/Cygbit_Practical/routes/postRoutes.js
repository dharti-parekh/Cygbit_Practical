const express = require('express');
const router = express.Router();
const User = require('./../models/Users');
const Post = require('./../models/Posts');
const { jwtAuthMiddleware } = require('./../jwt');

//Create a new post of logged in user
router.post('', jwtAuthMiddleware, async (req, res) => {
    try {
        const data = req.body
        //check user is logged in
        const result = await User.find({ _id: data.userId })
        if (result) {
            const newPost = new Post(data);

            // Save the new post to the database
            const response = await newPost.save();
            console.log('data saved');

            res.status(200).json({ result: response });
        } else {
            return res.status(400).json({ error: 'User not exists' });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

//list of all the posts
router.get('', jwtAuthMiddleware, async (req, res) => {
    const limit = parseInt(req.query.limit) || 10;
    const page = parseInt(req.query.page) || 1;
    const skip = (page - 1) * limit;

    try {
        const totalPosts = await Post.countDocuments({ userId: req.user.id });
        const posts = await Post.aggregate([
            { $match: { userId: req.user.id } },
            { $sort: { createdAt: -1 } },
            { $skip: skip },
            { $limit: limit }
        ]);

        res.json({
            page,
            limit,
            totalPosts,
            posts
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

// Retrieve details of a specific post by ID.
router.get('/:id', jwtAuthMiddleware, async (req, res) => {
    const postId = req.params.id;
    const userId = req.user.id;

    try {
        const post = await Post.findOne({ _id: postId });

        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }

        if (post.userId.toString() !== userId.toString()) {
            return res.status(403).json({ message: 'You are not authorized to view this post' });
        }

        res.json(post);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

//remove post api
router.delete('/:id', jwtAuthMiddleware, async (req, res) => {
    const postId = req.params.id;
    const userId = req.user.id;

    try {
        const post = await Post.findOne({ _id: postId });

        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }

        if (post.userId.toString() !== userId.toString()) {
            return res.status(403).json({ message: 'You are not authorized to delete this post' });
        }

        await Post.deleteOne({ _id: postId });

        res.json({ message: 'Post deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

//update post created by the user
router.patch('/:id', jwtAuthMiddleware, async (req, res) => {
    const postId = req.params.id;
    const userId = req.user.id;
    const { title, content } = req.body;

    try {
        const post = await Post.findOne({ _id: postId });

        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }

        if (post.userId.toString() !== userId.toString()) {
            return res.status(403).json({ message: 'You are not authorized to update this post' });
        }

        post.title = title || post.title;
        post.content = content || post.content;
        await post.save();

        res.json({ message: 'Post updated successfully', post });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
})

module.exports = router;