const mongoose = require('mongoose');

const PostSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    content: {
        type: String,
        required: true
    },
    userId: {
        type: String,
        required: true,
        ref: 'Users'
    }
});

const Posts = mongoose.model('Posts', PostSchema);
module.exports = Posts;